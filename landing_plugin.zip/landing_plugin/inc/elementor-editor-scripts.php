<?php

   /*
	 * Register Editor Script
	*/



