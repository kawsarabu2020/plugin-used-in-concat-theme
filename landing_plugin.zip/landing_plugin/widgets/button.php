<?php

class Landing_Button extends \Elementor\Widget_Base {

	public function get_name() {
		return 'button';
	}

	public function get_title() {
		return esc_html__( 'Landing Button', 'landing_plugin' );
	}

	public function get_icon() {
		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'landing-wp' ];
	}

	public function get_keywords() {
		return [ 'landing', 'button' ];
	}

   
   protected function register_controls() {

   $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Button Settings', 'landing_plugin' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
    );

   $this->add_control(
			'btn_text',
			[
			'label' => esc_html__( 'Button Text', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'know about us', 'landing_plugin' ),				
			]
	);

   $this->add_control(
			'btn_link',
			[
				'label' => esc_html__( 'Button Link Address', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::URL,
				'default' => [
					'url' => '#about',
				],
				'label_block' => false,
			]
	);


   $this->add_control(
			'btn_icon',
			[
				'label' => esc_html__( 'Button Icon', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-chevron-right',
					'library' => 'fa-solid fa-chevron-right',
				],
				'recommended' => [
					'fa-solid' => [
						'circle',
						'dot-circle',
						'square-full',
					],
					'fa-regular' => [
						'circle',
						'dot-circle',
						'square-full',
					],
				],
			]
		);



   // $this->add_control(
// 			'website_link',
// 			[
// 				'label' => esc_html__( 'Link', 'textdomain' ),
// 				'type' => \Elementor\Controls_Manager::URL,
// 				'options' => [ 'url', 'is_external', 'nofollow' ],
// 				'default' => [
// 					'url' => '',
// 					'is_external' => true,
// 					'nofollow' => true,
// 					// 'custom_attributes' => '',
// 				],
// 				'label_block' => true,
// 			]
// 		);



	$this->end_controls_section();

   $this->start_controls_section(
			'style_button',
			[
				'label' => esc_html__( 'Button Style', 'landing_plugin' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
	);

    $this->add_control(
			'btn_width',
			[
				'label' => esc_html__( 'Width', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 200,
				],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper .slogan-button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'btn_border',
				'selector' => '{{WRAPPER}} .slogan-box-wrapper a.slogan-btn',
			]
		);

    $this->add_control(
			'btn_border_rad',
			[
				'label' => esc_html__( 'Border Radius', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper a.slogan-btn' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);
		


		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn_typography',
				'selector' => '{{WRAPPER}} .slogan-box-wrapper a.slogan-btn',
			]
		);


		$this->add_control(
			'btn_color',
			[
				'label' => esc_html__( 'Button Color', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper a.slogan-btn' => 'color: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'btn_bg_color',
			[
				'label' => esc_html__( 'Button BG Color', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slogan-box-wrapper a.slogan-btn' => 'background-color: {{VALUE}}',
				],
			]
		);


   $this->end_controls_section();


   }

	protected function render() { 
    
    $settings = $this->get_settings_for_display();

	?>


  		<!-- START BUTTON -->
  		  <button class="slogan-box-wrapper slogan-button">
		    <a class="section-scroll slogan-btn" href="<?php echo esc_attr ( $settings['btn_link'] ["url"] );?>" >
				<i class="<?php echo esc_attr ( $settings['btn_icon'] ["value"] );?>"></i> 
				<?php echo  wp_kses_post( $settings['btn_text'] );?>  
	        </a>
	      </button>	
	   
		<!-- END BUTTON -->

	<?php
	    
	}
/**
 * Render the widget output in the editor.
 *
 * Written as a Backbone JavaScript template and used to generate the live preview.
 *
 * @since 1.1.0
 *
 * @access protected
 */
protected function _content_template()
{ }
}