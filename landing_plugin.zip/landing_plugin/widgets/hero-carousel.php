<?php

class Landing_Carousel_Slider extends \Elementor\Widget_Base {

	public function get_name() {
		return 'hero-carousel-slider';
	}

	public function get_script_depends() {
		return [ 'landing-carousel','landing-fontawesome' ];
	}

	public function get_title() {
		return esc_html__( 'Landing Slider', 'landing_plugin' );
	}

	public function get_icon() {
		return 'eicon-slider-full-screen';
	}

	public function get_categories() {
		return [ 'landing-wp' ];
	}

	public function get_keywords() {
		return [ 'hero', 'slider' ];
	}

   
   protected function register_controls() {

   $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Slider Settings', 'landing_plugin' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
    );

   	$this->add_control(
			'carousel_items',
			[
				'label' => esc_html__( 'Hero Slide List', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'default' => [
					[
						'title' => esc_html__( 'We are santo', 'landing_plugin' ),
					],
					[
						'title' => esc_html__( 'Creative', 'landing_plugin' ),
					],
				],
				'fields' => [
					[
						'name' => 'image',
						'label' => esc_html__( 'Image', 'landing_plugin' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'default' => [
						    'url' => \Elementor\Utils::get_placeholder_image_src(),
						 ],
					],
					[
						'name' => 'title',
						'label' => esc_html__( 'Heading', 'landing_plugin' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'This is Heading' , 'landing_plugin' ),
						'label_block' => true,
					],
					[
						'name' => 'display_subtitle',
						'label' => esc_html__( 'Show / Hide Subtitle', 'landing_plugin' ),
						'type' => \Elementor\Controls_Manager::SWITCHER,
						'label_on' => esc_html__( 'Yes', 'landing_plugin' ),
						'label_off' => esc_html__( 'No', 'landing_plugin' ),
						'return_value' => 'yes',
				        'default' => 'yes',
					],
					[
						'name' => 'subtitle',
						'label' => esc_html__( 'SubHeading', 'landing_plugin' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'This is SubHeading' , 'landing_plugin' ),
						'condition' => [
					      'display_subtitle' => 'yes',
				        ],
					],
					[
						'name' => 'display_desc',
						'label' => esc_html__( 'Show / Hide Descrption', 'landing_plugin' ),
						'type' => \Elementor\Controls_Manager::SWITCHER,
						'label_on' => esc_html__( 'Yes', 'landing_plugin' ),
						'label_off' => esc_html__( 'No', 'landing_plugin' ),
						'return_value' => 'yes',
				        'default' => 'no',
					],
					[
						'name' => 'desc',
						'label' => esc_html__( 'Descrption', 'landing_plugin' ),
						'type' => \Elementor\Controls_Manager::WYSIWYG,
						'default' => esc_html__( 'This is Description' , 'landing_plugin' ),
						'condition' => [
					      'display_desc' => 'yes',
				        ],
					],

				],

				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
				'add_content_section',
				[
					'label' => esc_html__( 'Additional Settings', 'landing_plugin' ),
					'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				]
	    );

		$this->add_control(
				'loop',
				[
					'label' => esc_html__( 'Loop', 'landing_plugin' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Show', 'landing_plugin' ),
					'label_off' => esc_html__( 'Hide', 'landing_plugin' ),
		 			'return_value' => 'yes',
		 			'default' => 'yes',
					'frontend_available' => true,

				]
			);

		$this->add_control(
			'lazy',
			[
				'label' => esc_html__( 'Lazyload', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'landing_plugin' ),
				'label_off' => esc_html__( 'Hide', 'landing_plugin' ),
		 		'return_value' => 'yes',
		 		'default' => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'landing_plugin' ),
				'label_off' => esc_html__( 'Hide', 'landing_plugin' ),
		 		'return_value' => 'yes',
		 		'default' => 'yes',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'play_speed',
			[
				'label' => esc_html__( 'Autoplay Speed', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 200,
				'max' => 15000,
				'step' => 5,
				'default' => 1500,
				'condition' => [
                  'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'in_anima',
			[
				'label' => esc_html__( 'In Animation', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'fadeIn',
				'options' => [
				'fadeIn' => esc_html__( 'FadeIn','landing_plugin' ),
					'fadeInUp' => esc_html__( 'FadeInUp','landing_plugin' ),
					'fadeInDown' => esc_html__( 'FadeInDown','landing_plugin' ),
					'fadeInDownBig' => esc_html__( 'FadeInDownBig','landing_plugin' ),
					'fadeInLeft' => esc_html__( 'FadeInLeft','landing_plugin' ),
					'fadeInLeftBig' => esc_html__( 'FadeInLeftBig','landing_plugin' ),
					'fadeInRight' => esc_html__( 'FadeInRight','landing_plugin' ),
					'fadeInRightBig' => esc_html__('FadeInRightBig','landing_plugin' ),
					'fadeInUpBig' => esc_html__( 'FadeInUpBig','landing_plugin' ),
					'fadeInTopLeft' => esc_html__( 'FadeInTopLeft','landing_plugin' ),
					'fadeInTopRight' => esc_html__( 'FadeInTopRight','landing_plugin' ),
					'fadeInBottomLeft' => esc_html__( 'FadeInBottomLeft','landing_plugin' ),
					'fadeInBottomRight' => esc_html__( 'FadeInBottomRight','landing_plugin' ),

					'slideInLeft' => esc_html__( 'SlideInLeft','landing_plugin' ),		
					'slideInDown' => esc_html__( 'SlideInDown','landing_plugin' ),
					'slideInLeft' => esc_html__( 'SlideInLeft','landing_plugin' ),
					'slideInRight' => esc_html__( 'SlideInRight','landing_plugin' ),
					'slideInUp' => esc_html__( 'SlideInUp','landing_plugin' ),

					'bounceIn' => esc_html__( 'BounceIn','landing_plugin' ),
					'backInDown' => esc_html__( 'BackInDown','landing_plugin' ),
					'backInLeft' => esc_html__( 'BackInLeft','landing_plugin' ),
					'backInRight' => esc_html__( 'BackInRight','landing_plugin' ),
					'backInUp' => esc_html__( 'BackInUp','landing_plugin' ),
					'bounceInDown' => esc_html__( 'BounceInDown','landing_plugin' ),
					'bounceInLeft' => esc_html__( 'BounceInLeft','landing_plugin' ),
					'bounceInRight' => esc_html__( 'BounceInRight','landing_plugin' ),
					'bounceInUp' => esc_html__( 'BounceInUp','landing_plugin' ),

					'flip' => esc_html__( 'Flip','landing_plugin' ),
					'flipInX' => esc_html__( 'FlipInX','landing_plugin' ),
					'flipInY' => esc_html__( 'FlipInY','landing_plugin' ),


					'lightSpeedInRight' => esc_html__( 'LightSpeedInRight','landing_plugin' ),
					'lightSpeedInLeft' => esc_html__( 'LightSpeedInLeft','landing_plugin' ),


	            	'rotateIn' => esc_html__( 'RotateIn','landing_plugin' ),
					'rotateInDownLeft' => esc_html__( 'RotateInDownLeft','landing_plugin' ),
					'rotateInDownRight' => esc_html__( 'RotateInDownRight','landing_plugin' ),
					'rotateInUpLeft' => esc_html__( 'RotateInUpLeft','landing_plugin' ),
					'rotateInUpRight' => esc_html__( 'RotateInUpRight','landing_plugin' ),

                	'hinge' => esc_html__( 'Hinge','landing_plugin' ),
					'jackInTheBox' => esc_html__( 'JackInTheBox','landing_plugin' ),
					'rollIn' => esc_html__( 'RollIn','landing_plugin' ),

					'zoomIn' => esc_html__( 'Zoom In','landing_plugin' ),
					'zoomInDown' => esc_html__( 'zoomInDown','landing_plugin' ),
					'zoomInLeft' => esc_html__( 'zoomInLeft','landing_plugin' ),
					'zoomInRight' => esc_html__( 'zoomInRight','landing_plugin' ),
					'zoomInUp' => esc_html__( 'zoomInUp','landing_plugin' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'out_anima',
			[
				'label' => esc_html__( 'Out Animation', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'fadeOut',
				'options' => [
				'fadeOut' => esc_html__( 'FadeOut','landing_plugin' ),
					'fadeOutDown' => esc_html__( 'FadeOutDown','landing_plugin' ),
					'fadeOutDownBig' => esc_html__( 'FadeOutDownBig','landing_plugin' ),
					'fadeOutLeft' => esc_html__( 'FadeOutLeft','landing_plugin' ),
					'fadeOutLeftBig' => esc_html__( 'FadeOutLeftBig','landing_plugin' ),
					'fadeOutRight' => esc_html__( 'FadeOutRight','landing_plugin' ),
					'fadeOutRightBig' => esc_html__('FadeOutRightBig','landing_plugin' ),
					'fadeOutUp' => esc_html__( 'FadeOutUp','landing_plugin' ),
					'fadeOutUpBig' => esc_html__( 'FadeOutUpBig','landing_plugin' ),
					'fadeOutTopLeft' => esc_html__( 'FadeOutTopLeft','landing_plugin' ),
					'fadeOutTopRight' => esc_html__( 'FadeOutTopRight','landing_plugin' ),
					'fadeOutBottomRight' => esc_html__( 'FadeOutBottomRight','landing_plugin' ),
					'fadeOutBottomLeft' => esc_html__( 'FadeOutBottomLeft','landing_plugin' ),

					'slideOutDown' => esc_html__( 'SlideOutDown','landing_plugin' ),
					'slideOutLeft' => esc_html__( 'SlideOutLeft','landing_plugin' ),
					'slideOutRight' => esc_html__( 'SlideOutRight','landing_plugin' ),
					'slideOutUp' => esc_html__( 'SlideOutUp','landing_plugin' ),


					'backOutDown' => esc_html__( 'BackOutDown','landing_plugin' ),
					'backOutLeft' => esc_html__( 'BackOutLeft','landing_plugin' ),
					'backOutRight' => esc_html__( 'BackOutRight','landing_plugin' ),
					'backOutUp' => esc_html__( 'BackOutUp','landing_plugin' ),

					'bounceOutDown' => esc_html__( 'BounceOutDown','landing_plugin' ),
					'bounceOutLeft' => esc_html__( 'BounceOutLeft','landing_plugin' ),
					'bounceOutRight' => esc_html__( 'BounceOutRight','landing_plugin' ),
					'bounceOutUp' => esc_html__( 'BounceOutUp','landing_plugin' ),

					'flipOutX' => esc_html__( 'FlipOutX','landing_plugin' ),
					'flipOutY' => esc_html__( 'FlipOutY','landing_plugin' ),

					'lightSpeedOutRight' => esc_html__( 'LightSpeedOutRight','landing_plugin' ),
					'lightSpeedOutLeft' => esc_html__( 'LightSpeedOutLeft','landing_plugin' ),

	                'rotateOut' => esc_html__( 'RotateOut','landing_plugin' ),
					'rotateOutDownLeft' => esc_html__( 'RotateOutDownLeft','landing_plugin' ),
					'rotateOutDownRight' => esc_html__( 'RotateOutDownRight','landing_plugin' ),
					'rotateOutUpLeft' => esc_html__( 'RotateOutUpLeft','landing_plugin' ),
					'rotateOutUpRight' => esc_html__( 'RotateOutUpRight','landing_plugin' ),

                    'hinge' => esc_html__( 'Hinge','landing_plugin' ),
					'jackInTheBox' => esc_html__( 'JackInTheBox','landing_plugin' ),
					'rollOut' => esc_html__( 'RollOut','landing_plugin' ),

				    'zoomOut' => esc_html__( 'ZoomOut','landing_plugin' ),
					'zoomOutDown' => esc_html__( 'ZoomOutDown','landing_plugin' ),
					'zoomOutLeft' => esc_html__( 'ZoomOutLeft','landing_plugin' ),
					'zoomOutRight' => esc_html__( 'ZoomOutRight','landing_plugin' ),
					'zoomOutUp' => esc_html__( 'ZoomOutUp','landing_plugin' ),
				],
				'frontend_available' => true,
			]
		);

	    $this->end_controls_section();


         $this->start_controls_section(
				'slider_height_style',
				[
					'label' => esc_html__( 'Height & Opacity ', 'landing_plugin' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
	    );




         $this->add_control(
			'slider_height',
			[
				'label' => esc_html__( 'Height', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem','vh', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'vh' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 800,
				],
				'selectors' => [
					'{{WRAPPER}} .home-sliders .single-slide-item' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);


         $this->add_control(
		'slider_bg_overlay_color',
		[
			'label' => esc_html__( 'BG Overlay', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .home-sliders .single-slide-item:after' => 'background-color: {{VALUE}}',
			],
		  ]
	    );

		$this->add_control(
			'slider_bg_overlay_opacity',
			[
				'label' => esc_html__( 'Opacity', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .home-sliders .single-slide-item:after' => 'opacity: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();


	 	$this->start_controls_section(
				'slider_subheading_style',
				[
					'label' => esc_html__( 'SubHeading ', 'landing_plugin' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
	    );

		$this->add_control(
			'slider_sub_heading_align',
			[
				'label' => esc_html__( 'Alignment', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'landing_plugin' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'landing_plugin' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'landing_plugin' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} h2.slider-sub-heading' => 'text-align: {{VALUE}};',
				],
			]
		);


	$this->add_group_control(
		\Elementor\Group_Control_Typography::get_type(),
		[
			'name' => 'slider_sub_heading_typo',
			'selector' => '{{WRAPPER}} h2.slider-sub-heading',
		]
	);


	$this->add_control(
		'slider_sub_heading_color',
		[
			'label' => esc_html__( 'Sub Heading Color', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} h2.slider-sub-heading' => 'color: {{VALUE}}',
			],
		]
	);


	$this->add_control(
		'slider_top_border_top_btm',
		[
			'label' => esc_html__( 'Space From Top / Bottom', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'range' => [
				'px' => [
					'min' => -500,
					'max' => 1000,
					'step' => 5,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'default' => [
				'unit' => 'px',
				'size' => 105,
			],
			'selectors' => [
				'{{WRAPPER}} h2.slider-sub-heading.top-border' => 'top: {{SIZE}}{{UNIT}};',
			],
		]
	);


    $this->end_controls_section();


    $this->start_controls_section(
				'top_border_style',
				[
					'label' => esc_html__( 'Top Border ', 'landing_plugin' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
	);


	$this->add_control(
		'slider_top_border_top_btm',
		[
			'label' => esc_html__( 'Space From Top / Bottom', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'range' => [
				'px' => [
					'min' => -500,
					'max' => 1000,
					'step' => 5,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'default' => [
				'unit' => 'px',
				'size' => 105,
			],
			'selectors' => [
				'{{WRAPPER}} .single-slide-content-wrapper h2.slider-sub-heading .top-border' => 'top: {{SIZE}}{{UNIT}};',
			],
		]
	);


	$this->add_responsive_control(
		'slider_top_border_align',
		[
			'label' => esc_html__( 'Alignment', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::CHOOSE,
			'options' => [
				'left' => [
					'title' => esc_html__( 'Left', 'landing_plugin' ),
					'icon' => 'eicon-text-align-left',
				],
				'center' => [
					'title' => esc_html__( 'Center', 'landing_plugin' ),
					'icon' => 'eicon-text-align-center',
				],
				'right' => [

					'title' => esc_html__( 'Right', 'landing_plugin' ),
					'icon' => 'eicon-text-align-right',
				],
			],
			'default' => 'left',
			'toggle' => true,
			'selectors' => [
				'{{WRAPPER}} .single-slide-content-wrapper h2.slider-sub-heading .top-border' => 'text-align: {{VALUE}}',
			],
		]
	);


	$this->add_group_control(
		\Elementor\Group_Control_Border::get_type(),
		[
			'name' => 'slider_sub_heading_top_border',
			'selector' => '{{WRAPPER}} h2.slider-sub-heading.top-border',
		]
	);


	$this->add_control(
		'slider_top_border_width',
		[
			'label' => esc_html__( 'Width', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
			'range' => [
				'px' => [
					'min' => -500,
					'max' => 1000,
					'step' => 5,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'default' => [
				'unit' => '%',
				'size' => 100,
			],
			'selectors' => [
				'{{WRAPPER}} .single-slide-content-wrapper h2.slider-sub-heading .top-border' => 'width: {{SIZE}}{{UNIT}};',
			],
		]
	);


    $this->end_controls_section();

    $this->start_controls_section(
				'slider_heading_style',
				[
					'label' => esc_html__( 'Heading', 'landing_plugin' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
	    );


	$this->add_control(
		'slider_heading_align',
		[
			'label' => esc_html__( 'Alignment', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::CHOOSE,
			'options' => [
				'left' => [
					'title' => esc_html__( 'Left', 'landing_plugin' ),
					'icon' => 'eicon-text-align-left',
				],
				'center' => [
					'title' => esc_html__( 'Center', 'landing_plugin' ),
					'icon' => 'eicon-text-align-center',
				],
				'right' => [
					'title' => esc_html__( 'Right', 'landing_plugin' ),
					'icon' => 'eicon-text-align-right',
				],
			],
			'default' => 'center',
			'toggle' => true,
			'selectors' => [
				'{{WRAPPER}} h1.slider-heading' => 'text-align: {{VALUE}};',
			],
		]
	);


	$this->add_group_control(
		\Elementor\Group_Control_Typography::get_type(),
		[
			'name' => 'slider_heading_typo',
			'selector' => '{{WRAPPER}} h1.slider-heading',
		]
	);


	$this->add_control(
		'slider_heading_color',
		[
			'label' => esc_html__( 'Color', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .single-slide-content-wrapper h1.slider-heading' => 'color: {{VALUE}}',
			],
		]
	);

     $this->end_controls_section();

     $this->start_controls_section(
			'btm_border_style',
			[
				'label' => esc_html__( 'Bottom Border', 'landing_plugin' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
	);


     $this->add_control(
		'btm_border_show_hide',
				[
					'label' => esc_html__( 'Show / Hide', 'landing_plugin' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Show', 'landing_plugin' ),
					'label_off' => esc_html__( 'Hide', 'landing_plugin' ),
		 			'return_value' => 'yes',
		 			'default' => 'yes',
					'frontend_available' => true,

				]
		);

     $this->add_responsive_control(
		'slider_btm_border_align',
		[
			'label' => esc_html__( 'Alignment', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::CHOOSE,
			'options' => [
				'left' => [
					'title' => esc_html__( 'Left', 'landing_plugin' ),
					'icon' => 'eicon-text-align-left',
				],
				'center' => [
					'title' => esc_html__( 'Center', 'landing_plugin' ),
					'icon' => 'eicon-text-align-center',
				],
				'right' => [

					'title' => esc_html__( 'Right', 'landing_plugin' ),
					'icon' => 'eicon-text-align-right',
				],
			],
			'default' => 'center',
			'toggle' => true,
			'selectors' => [
				'{{WRAPPER}} .home-sliders .bottom-border' => 'text-align: {{VALUE}}',
			],
		]
	);



	$this->add_group_control(
		\Elementor\Group_Control_Border::get_type(),
		[
			'name' => 'slider_heading_btm_border',
			'selector' => '{{WRAPPER}} .home-sliders .bottom-border',
		]
	);

	$this->add_control(
		'slider_bottom_border_top_btm',
		[
			'label' => esc_html__( 'Space From Top / Bottom', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'range' => [
				'px' => [
					'min' => -500,
					'max' => 1000,
					'step' => 5,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'default' => [
				'unit' => 'px',
				'size' => 105,
			],
			'selectors' => [
				'{{WRAPPER}} .home-sliders .bottom-border' => 'top: {{SIZE}}{{UNIT}};',
			],
		]
	);


	$this->add_control(
		'slider_btm_border_width',
		[
			'label' => esc_html__( 'Width', 'landing_plugin' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
			'range' => [
				'px' => [
					'min' => -500,
					'max' => 1000,
					'step' => 5,
				],
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'default' => [
				'unit' => '%',
				'size' => 10,
			],
			'selectors' => [
				'{{WRAPPER}} .home-sliders .bottom-border' => 'width: {{SIZE}}{{UNIT}};',
			],
		]
	);

    $this->end_controls_section();

	$this->start_controls_section(
			'style_section_nav',
			[
				'label' => esc_html__( 'Navigation Style', 'landing_plugin' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
	);

	    $this->add_control(
			'owl_nav_dots',
			[
				'label' => esc_html__( 'Navigation', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'both',
				'options' => [
					'both' => esc_html__( 'Nav and Dots', 'landing_plugin' ),
					'nav' => esc_html__( 'Nav', 'landing_plugin' ),
					'dots' => esc_html__( 'Dots', 'landing_plugin' ),
					'none' => esc_html__( 'None', 'landing_plugin' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'prev_nav_icon',
			[
				'label' => esc_html__( 'Prev Arrow Icon', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'skin' => 'inline',
				'label_block' => false,
				'skin_settings' => [
					'inline' => [
						'none' => [
							'label' => 'Default',
							'icon' => 'fas fa-chevron-left',
						],
						'icon' => [
					      'icon' => 'fas fa-cog',
				        ],
				    ],    
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','nav']
				]
			],
			
		);


		$this->add_control(
			'next_nav_icon',
			[
				'label' => esc_html__( 'Next Arrow Icon', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'skin' => 'inline',
				'label_block' => false,
				'skin_settings' => [
					'inline' => [
						'none' => [
							'label' => 'Default',
							'icon' => 'fas fa-chevron-right',
						],
						'icon' => [
					      'icon' => 'fas fa-cog',
				        ],
				    ],    
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','nav']
				]
			],
			
		);

        $this->end_controls_section();

		$this->start_controls_section(
				'prev_nav_style_section',
				[
					'label' => esc_html__( 'Previous Nav', 'landing_plugin' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
	    );

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'owl_prev_border',
				'selector' => '{{WRAPPER}} .owl-prev',
				'condition' =>[
                   'owl_nav_dots' => ['both','nav'],
			    ],
			]
		);

        $this->add_control(
			'owl_nav_width',
			[
				'label' => esc_html__( 'Nav Width', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .owl-prev, {{WRAPPER}} .owl-next' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','nav'],
			    ],
			]
		);


        $this->add_control(
			'owl_nav_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .owl-prev, {{WRAPPER}} .owl-next' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','nav'],
			    ],
			]
		);


        $this->add_control(
			'nav_size',
			[
				'label' => esc_html__( 'Nav Arrow Size', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .owl-prev > i, {{WRAPPER}} .owl-next > i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','nav'],
			    ],
			]
		);

		$this->end_controls_section();

       $this->start_controls_section(
			'next_nav_style_options',
			[
				'label' => esc_html__( 'Next Nav', 'landing_plugin' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
	    );


		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'owl_nav_border',
				'selector' => '{{WRAPPER}} .owl-prev , {{WRAPPER}} .owl-next',
				'condition' =>[
                   'owl_nav_dots' => ['both','nav'],
			    ],
			]
		);


		 $this->add_control(
			'owl_nav_height',
			[
				'label' => esc_html__( 'Nav Height', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .owl-prev, {{WRAPPER}} .owl-next' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','nav'],
			    ],
			]
		);

		$this->add_control(
			'owl_next_nav_margin_from_left',
			[
				'label' => esc_html__( 'Space Right', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .owl-next' => 'right: {{SIZE}}{{UNIT}};',
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','nav'],
			    ],
			]
		);



        $this->add_control(
			'owl_nav_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .owl-prev','{{WRAPPER}} .owl-next' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','nav'],
			    ],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'dot_style_options',
			[
				'label' => esc_html__( 'Dots', 'landing_plugin' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
	    );


		$this->add_responsive_control(
			'owl_dots_alignment',
			[
				'label' => esc_html__( 'Owl Dots Alignment', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'landing_plugin' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'landing_plugin' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'landing_plugin' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .owl-dots' => 'text-align: {{VALUE}};',
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','dots']
				],
			]
		);


        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'owl_dot_border',
				'selector' => '{{WRAPPER}} button.owl-dot',
				'condition' =>[
                   'owl_nav_dots' => ['both','dots'],
			    ],
			],
			
		);


        $this->add_control(
			'owl_dot_nav_width_height',
			[
				'label' => esc_html__( 'Dot Width & Height', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} button.owl-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','dots']
				],
			]
		);

		$this->add_control(
			'owl_dot_margin_from_left',
			[
				'label' => esc_html__( 'Space Left', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} button.owl-dot' => 'position:absolute',
					'{{WRAPPER}} button.owl-dot' => 'left: {{SIZE}}{{UNIT}};',
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','dots']
				],
			]
		);


        $this->add_control(
			'owl_dot_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} button.owl-dot' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
				'condition' =>[
                   'owl_nav_dots' => ['both','dots']
				],
			]
		);


        $this->add_control(
		'owl_dot_active_bg_color',
			[
				'label' => esc_html__( 'Active Bg Color', 'landing_plugin' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} button.owl-dot.active' => 'background: {{VALUE}}!important',
				],
			]
	    );

	    $this->end_controls_section();

	   }

	protected function render() { 
    
    $settings = $this->get_settings_for_display();

    $unique_id  = rand('2587','1478');

      $nav = '';
      $dots = '';
      $loop = '';  
      $lazy = '';
      $autoplay = '';
      $playSpeed = '';
      $in_anima = '';
      $out_anima = '';
      $prev_nav_icon = '';
      $next_nav_icon = '';

      $nav = $settings['owl_nav_dots'] === 'nav' ? 'true' : 'false';
      $dots = $settings['owl_nav_dots'] === 'dots' ? 'true' : 'false';

      if( $settings['owl_nav_dots'] === 'both'){
        $nav = $settings['owl_nav_dots'] === 'both' ? 'true' : 'false';
        $dots = $settings['owl_nav_dots'] === 'both' ? 'true' : 'false';
      }

      if($nav && $dots == 'none'){
      	$nav && $dots === 'false';
      }
   
	?>

    <!-- START-SLIDER -->
	<section id="<?php echo $unique_id;?>" class="home-sliders owl-carousel">
		<?php 
		   if ( $settings['carousel_items'] ):
		   foreach( $settings['carousel_items'] as  $slider ):
		?>

	    <div style="background-image:url(<?php echo esc_url ( $slider['image']['url']); ?>);" class="single-slide-item  hero-bg overay-color">
	    	
			<div class="single-slide-content-wrapper">
				<div class="container-fluid content-inner">
                                      
                    <?php if($slider ['display_subtitle'] === 'yes'):?>

						<h2 class="slider-sub-heading"> 
							<?php echo wp_kses_post ( $slider['subtitle'] );?>	
							   <span class="top-border"></span>                 
						</h2>

                    <?php endif;?>
					<?php 
					    $slider['title'] = $slider['title'] ? $slider['title'] : " ";
					?>

					<h1 class="slider-heading"> 
					    <?php echo wp_kses_post( $slider['title'] );?> 					           
					</h1>	
                        
                    <?php  
                       $slider['desc'] = $slider ['display_desc'] === 'yes' ?  $slider['desc'] :  " "; 
                    ?>

					<?php echo wpautop( $slider['desc'] );?> 	

                    <?php if( $settings['btm_border_show_hide'] === 'yes' ):?>
				      <span class="bottom-border"></span>
				    <?php endif;?>

				</div><!--/.content-inner-->
			</div><!--single-hero-bg-content-wrapper-->
		</div><!--single-slide-item-->

        <?php 
         endforeach;
         endif;

        ?>


	</section><!-- sliders -->
	
	<!-- END-SLIDER -->


	<script>

	(function($) {
		"use strict";
		jQuery( document ).ready(function ($) {
			var homeSlider = $('.home-sliders');
	   		 homeSlider.owlCarousel({
					   items: 1,
					     rtl: true,
					    loop: <?php echo $loop = $settings['loop'] === 'yes' ? 'true' : 'false'; ?>,
					lazyLoad: <?php echo $lazy = $settings['lazy'] === 'yes' ? 'true' : 'false'; ?>,
				    autoplay: <?php echo $autoplay = $settings['autoplay'] === 'yes' ? 'true' : 'false'; ?>,
				  smartSpeed: <?php echo $playSpeed = $settings['play_speed'] ? $autoplay : 'false'; ?>,
				   animateIn: '<?php echo $in_anima = $settings['in_anima']; ?>',
				  animateOut: '<?php echo $out_anima = $settings['out_anima']; ?>',
					    dots: <?php if($dots){echo $dots;}?>,
					     nav: <?php if($nav){echo $nav;}?>,
					 navText: 
					 [
			          "<i class='<?php echo $prev_nav_icon = $settings['prev_nav_icon']['value'] ? $settings['prev_nav_icon']['value'] : 'fas fa-chevron-left';
					  ?>'></i>",

					  "<i class='<?php echo $next_nav_icon = $settings['next_nav_icon']['value'] ? $settings['next_nav_icon']['value'] : 'fas fa-chevron-right';
					  ?>'></i>"
					  ]
			   });	
		   });

       }(jQuery));


    </script>
	<?php
	    
	}
/**
 * Render the widget output in the editor.
 *
 * Written as a Backbone JavaScript template and used to generate the live preview.
 *
 * @since 1.1.0
 *
 * @access protected
 */
protected function _content_template()
{ }
}