// (function($) {
//     "use strict";  


//  //*-------------SINGLE-WORK-CAROUSEL--------------*//	 	 
	
// 	var workSliders = $('.workSlider');
// 	workSliders.owlCarousel({
//         items: 1,
//         loop: true,
//         smartSpeed: 1000,
//         autoplay: true,
// 		animateIn: 'fadeIn',
// 		animateOut: 'fadeOut',
// 		mouseDrag:false,
//         dots: false,
//         nav: true,
// 		navText: ["<i class='fa-solid fa-chevron-left'></i>",
//             "<i class='fa-solid fa-chevron-right'></i>"
//         ]
//     });	
// }(jQuery));